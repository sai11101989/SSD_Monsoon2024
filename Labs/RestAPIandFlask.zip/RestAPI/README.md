
1. Install the required packages:
```bash
pip install flask flask-sqlalchemy requests
```

2. Create the project structure:
```
todo_api/
├── app.py
├── models.py
├── test_api.py
└── todos.db (will be created automatically)
```

3. Start the API server:
```bash
python app.py
```
4. In a separate terminal, run the test script:
```bash
python test_api.py
```
