import requests
import json
from datetime import datetime

BASE_URL = 'http://localhost:5000'

def create_todo(title, completed=False):
    """Create a new todo item"""
    todo_data = {
        "title": title,
        "completed": completed
    }
    response = requests.post(f"{BASE_URL}/todos", json=todo_data)
    print("\nCREATE Todo:")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    return response.json()

def get_all_todos():
    """Retrieve all todo items"""
    response = requests.get(f"{BASE_URL}/todos")
    print("\nGET All Todos:")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    return response.json()

def update_todo(todo_id, title=None, completed=None):
    """Update a todo item"""
    update_data = {}
    if title is not None:
        update_data["title"] = title
    if completed is not None:
        update_data["completed"] = completed

    response = requests.put(f"{BASE_URL}/todos/{todo_id}", json=update_data)
    print("\nUPDATE Todo:")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    return response.json()

def delete_todo(todo_id):
    """Delete a todo item"""
    response = requests.delete(f"{BASE_URL}/todos/{todo_id}")
    print("\nDELETE Todo:")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    return response.json()

def run_api_tests():
    """Run a complete test suite"""
    print("\n=== Starting API Tests ===")

    # Test 1: Create first todo
    print("\nTest 1: Creating first todo")
    first_todo = create_todo("Learn SQLite with Flask")
    first_todo_id = first_todo['id']

    # Test 2: Create second todo
    print("\nTest 2: Creating second todo")
    second_todo = create_todo("Master Python Flask")

    # Test 3: Get all todos
    print("\nTest 3: Getting all todos")
    all_todos = get_all_todos()

    # Test 4: Update first todo
    print("\nTest 4: Updating first todo")
    updated_todo = update_todo(
        first_todo_id,
        title="Learn SQLite with Flask - Completed!",
        completed=True
    )

    # Test 5: Delete first todo
    print("\nTest 5: Deleting first todo")
    deleted_todo = delete_todo(first_todo_id)

    # Test 6: Verify deletion
    print("\nTest 6: Verifying deletion")
    final_todos = get_all_todos()

    print("\n=== API Tests Completed ===")

def test_individual_endpoints():
    """Example of how to test individual endpoints"""
    print("\n=== Testing Individual Endpoints ===")
    
    # Test only creation
    print("\nTesting only CREATE endpoint:")
    new_todo = create_todo("Test Individual Creation")
    
    # Test only reading
    print("\nTesting only GET endpoint:")
    get_all_todos()
    
    # Test only updating
    print("\nTesting only UPDATE endpoint:")
    update_todo(new_todo['id'], completed=True)
    
    # Test only deletion
    print("\nTesting only DELETE endpoint:")
    delete_todo(new_todo['id'])

if __name__ == "__main__":
    # Run all tests
    run_api_tests()
    
    # Uncomment to test individual endpoints
    # test_individual_endpoints() 